﻿using System;

namespace MovieStore.Core
{
    public class Class1
    {
    }
}
