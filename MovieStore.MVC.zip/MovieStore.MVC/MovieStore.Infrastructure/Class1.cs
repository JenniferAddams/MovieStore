﻿using System;

namespace MovieStore.Infrastructure
{
    public class Class1
    {
    }
}
